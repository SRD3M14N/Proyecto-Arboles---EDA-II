/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package arbolAritmetico.Main;

import java.util.Scanner;

/**
 *
 * @author ivansukas
 */
public class Main {
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
    
        MenuET.menu(leer);
        leer.close();
    }
    
}
